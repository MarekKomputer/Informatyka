#include <iostream>
using namespace std;

void Insert(double &d, string &s) // &odwo�uje sie do pami�ci komputera
{
    cin >> d;
    cin >> s;
}

double Power(double d, string s)
{
    double y = 1;
    for (int i = 0; i < s.length(); i++)
    {
        y = y * y;
        if (s[i] == '1')
            y = y * d;
    }

    return y;
}

int main()
{
    double d;
    string s;

    Insert(d, s);

    cout << Power(d, s) << '\n';

    return 0;
}
