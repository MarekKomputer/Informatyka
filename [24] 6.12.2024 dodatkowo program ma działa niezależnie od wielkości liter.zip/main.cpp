#include <iostream>
#include <vector>
using namespace std;

vector<int> result(string printer, string pattern)
{
    vector<int> indeces;

    if (printer.length() >= pattern.length())
    {
        int i = 0;
        int j;

        while (printer.length() - pattern.length() >= i)
        {
            j = 0;
            while (j < pattern.length() && printer[i+j] == pattern[j])
                j++;
            if (j == pattern.length())
            {
                indeces.push_back(i);
                i += j;
            }
            else
                i++;
        }
    }
    else
    {
        indeces.push_back(-1);
        return indeces;
    }

    return indeces;
}

int main()
{
    // zamiana ka�dego z liter z string na ma�e lub du�e
    // nie dzia�a vector

    string printer; // = "ALAMAKOTA";
    string pattern; // = "MA";

    cin >> printer >> pattern;

    vector<int> indeces = result(printer, pattern);

    for (int i = 0; i < indeces.size(); i++)
        cout << indeces[i] << '\n';

    /*
    printer.uppercase;

    string printer2 = toupper(printer[]);
    string pattern2 = toupper(pattern[]);
    */

    /*
    if (printer.length() >= pattern.length())
    {
        int i = 0;
        int j;

        while (printer.length() - pattern.length() >= i)
        {
            j = 0;
            while (j < pattern.length() && printer[i+j] == pattern[j])
                j++;
            if (j == pattern.length())
            {
                cout << i << '\n';
                i += j;
                cout << i - 1 << '\n';
            }
            else
                i++;
        }
    }
    */

    return 0;
}
