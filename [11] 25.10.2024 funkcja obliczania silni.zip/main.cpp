#include <iostream>
using namespace std;

long long factorial_iteration (int n)
{
    long long m = 1;
    for (int i = 1; i <= n; i++)
        m *= i;
    return m;
}

long long factorial_recursion (int n)
{
    if (n == 1)
        return 1;
    return n * factorial_recursion(n - 1);
}

int main()
{
    int n;
    cin >> n;

    cout << factorial_iteration(n) << ' ' << factorial_recursion(n) << '\n';

    return 0;
}
