#include <iostream>
using namespace std;

int main()
{
    string text = "dzisiajbedeplywacnawodzie";
    string pattern = "zdzislaw";
    int n = 0;
    int tab[pattern.length()] = {0}; // zerowanie kompletne tab

    for (int i = 0; i < pattern.length(); i++)
    {
        for (int j = 0; j < text.length(); j++)
            if (text[j] == pattern[i])
                tab[i]++;
        if (tab[i] > 0)
            n++;
    }
    if (n == pattern.length())
        cout << 1 << '\n';
    else
        cout << -1 << '\n';

    for (int i = 0; i < pattern.length(); i++)
        cout << pattern[i] << " = " << tab[i] << '\n';

    return 0;
}
