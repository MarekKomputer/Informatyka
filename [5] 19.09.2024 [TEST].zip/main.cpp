#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

int main()
{
    vector<vector<int>> nums;

    ifstream plik("liczby2txt.txt");

    vector<int> temp;
    int n;

    while(plik >> n)
    {
        temp.push_back(n);
        if (plik.peek() == '\n' || plik.peek() == EOF)
        {
            nums.push_back(temp);
            temp.clear();
        }
    }

    plik.close();

    for (const auto& row : nums)
        for (const auto& n : row)
            cout << n << ' ';
    cout << '\n';

    return 0;
}
