#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
using namespace std;

vector<double> d_we_x;
vector<double> d_we_y;
// dane wejœciowe

struct punkt
{
    double x, y;
};
// elementy zmiennej obiekty

vector<punkt> pkt;

int main()
{
    ifstream we("wuz2-zad-1-punktytxt.txt");

    punkt p[100];
    int i = 0;

    while (!we.eof())
    {
        we >> p[i].x >> p[i].y;
        d_we_x.push_back(p[i].x);
        d_we_y.push_back(p[i].x);
        pkt.push_back({p[i].x, p[i].y});
        i++;
    }

    we.close();

    cout << p[0].x << ' ' << p[0].y << '\n';

    for (auto& item : pkt)
        cout << item.x << ' ' << item.y << '\n';

    return 0;
}

/*
struct
{
    string name;
    string lastname;
    int age;
}

pkt zmienna;
zmienna.name="Jakub";
pkt zm[10];
zm[0].name="Marek";

vector<punkt> n     ={
{"Jakub","Nazwisko",15},
{"Marek","Zegarek",18}
};

vector<punkt> pkt = {
{5,10},
{8;13}
};

for (auto& item : items // tablice textów)
{

}
