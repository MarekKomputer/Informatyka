#include <iostream>
#include <string>
using namespace std;

void naive(string &text, string &pattern)
{
    int n = text.length();
    int m = pattern.length();

    for (int i = 0; i <= n - m; ++i)
    {
        if (text.substr(i, m) == pattern)
        {
            char first = (i > 0) ? text[i - 1] : '#';
            char last = (i + m < n) ? text[i + m] : '#';

            cout << first << '\n';
            // cout << pattern << '\n';
            cout << last << '\n';
        }
    }
}

int main()
{
    string text;// = "abcdario";
    string pattern;// = "abc";
    cin >> text >> pattern;

    naive(text, pattern);

    return 0;
}
