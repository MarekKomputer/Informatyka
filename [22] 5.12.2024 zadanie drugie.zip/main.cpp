#include <iostream>
#include <vector>
using namespace std;

int main()
{
    string dictionary[5] = {"japierpapier", "martin purta", "kibel", "bomba", "swistak"};
    vector<string> dictionar;
    dictionar.push_back("japierpapier");
    dictionar.push_back("martin purta");
    dictionar.push_back("kibel");
    dictionar.push_back("bomba");
    dictionar.push_back("swistak");
    char index = '1';
    string pattern = "";
    int wordLength = 0;

    while (index != "0")
    {
        cin >> index;
        pattern += index;
        int patternLength = pattern.length();

        for (int i = 0; i < 5; i++)
        {
            wordLength = dictionary[i].length();

            for (int j = 0; j < patternLength; j++)
            {
                for (int k = 0; k < wordLength; k++)
                    if (pattern[j] == wordLength[i][k])
                    {
                        cout << dictionary[i] << '\t';
                        break;
                    }
                cout << '\n';
            }
        }
        cout << '\n';
    }

    return 0;
}
