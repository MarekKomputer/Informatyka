#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main()
{
    int n;
    string s;

    ifstream fileNums("dane_ulamki.txt");
    ifstream fileTxts("teksttest.txt");

    vector<int> Nums;
    vector<string> Txts;

    while (!fileNums.eof())
    {
        fileNums >> n;
        Nums.push_back(n);
    }
    while (!fileTxts.eof())
    {
        fileTxts >> s;
        Txts.push_back(s);
    }

    for (auto& num : Nums)
        cout << num << '\n';
    for (auto& txt : Txts)
        cout << txt << '\n';

    return 0;
}
