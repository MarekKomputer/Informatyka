#include <iostream>
using namespace std;

int main()
{
    string dictionary[5] = {"japierpapier", "martin purta", "kibel", "bomba", "swistak"};
    char index = '1';
    string pattern = "";
    int wordlength = 0;

    while (pattern != '0')
    {
        cin >> index;
        pattern += index;

        for (int i = 0; i < 5; i++)
        {
            wordlength = dictionary[i].length();

            for (int i = 0; i < wordlength; i++)
            {
                for (int j=0; j<dl_t; j++)
                    if (t[j] == w[i])
                        arr[i]++;
            }
            if (arr[i] > 0 )
                ile++;
        }

    return 0;
}
