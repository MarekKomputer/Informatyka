#include <iostream>
#include <string>
using namespace std;

int main()
{
    int base;
    string number;
    int decValue = 0;

    cin >> base >> number;

    for (int i = 0; i < number.size(); i++)
    {
        int digit = number[i] - '0';

        decValue = decValue * base + digit;

        // cout << decValue << '\n';
        // JE�LI MA WYPISYWA� ZA KA�DYM RAZEM PO DZIA�ANIU
    }

    cout << decValue << '\n';

    return 0;
}
