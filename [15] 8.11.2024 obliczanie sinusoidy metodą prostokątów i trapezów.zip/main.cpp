#include <iostream>
#include <cmath>
using namespace std;

double Prostokat(double a, double b)
{
    return a * b;
}

double Trapez(double a, double b, double h)
{
    return ((a + b) * h) / 2;
}

double f(double x)
{
    return sin(x);
}

double ObszarTrapez(double a, double b, double n)
{
    // pole
    double MrV = 0;

    // zakres
    a = 0;
    b = M_PI;

    // podzia�
    cin >> n;

    double x = a;
    double f1 = f(x);
    double f2;

    // przedzia�
    double dx = (a + b) / n;

    for (int i = 0; i <= n; i++)
    {
        x += dx;
        f2 = f(x);
        MrV += Trapez(f1, f2, dx);
        f1 = f2;
    }

    return MrV;
}

double ObszarProstokat(double a, double b, double n)
{
    // pole
    double MrV = 0;

    // zakres
    a = 0;
    b = M_PI;

    // podzia�
    cin >> n;

    double x = a;

    // przedzia�
    double dx = (a + b) / n;

    for (int i = 0; i <= n; i++)
    {
        x += dx;
        MrV += Prostokat(dx, f(x));
    }

    return MrV;
}

int main()
{
    double n;

    cout << ObszarTrapez(0, M_PI, n) << '\n';
    cout << ObszarProstokat(0, M_PI, n) << '\n';

	return 0;
}
