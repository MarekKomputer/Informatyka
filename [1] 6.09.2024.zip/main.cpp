#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

int main()
{
    vector<int> vec;
    int n;

    ifstream file("liczby.txt");
    for (int i = 0; i < 10; i++)
        for (int j = 0; j < 5; j++)
        {
            file >> n;
            vec.push_back(n);
        }
    file.close();

    for (int i = 0; i < 10*5; i++)
        cout << vec[i] << ' ';

    ofstream file2("liczby2.txt");
    for (int i = 0; i < 10*5; i++)
        file2 << vec[i] << ' ';
    file2.close();

    return 0;
}
