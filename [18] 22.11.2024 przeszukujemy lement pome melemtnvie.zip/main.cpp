#include <iostream>
#include <vector>
using namespace std;

vector<int> result(string printer, string pattern)
{
    vector<int> indeces;

    if (printer.length() >= pattern.length())
    {
        int i = 0;
        int j;

        while (printer.length() - pattern.length() >= i)
        {
            j = 0;
            while (j < pattern.length() && printer[i+j] == pattern[j])
                j++;
            if (j == pattern.length())
            {
                indeces.push_back(i);
                i += j;
            }
            else
                i++;
        }
    }
    else
    {
        indeces.push_back(-1);
        return indeces;
    }

    return indeces;
}

int main()
{
    string printer; // = "ALAMAKOTA";
    string pattern; // = "MA";

    cin >> printer >> pattern;

    if (printer.length() >= pattern.length())
    {
        int i = 0;
        int j;

        while (printer.length() - pattern.length() >= i)
        {
            j = 0;
            while (j < pattern.length() && printer[i+j] == pattern[j])
                j++;
            if (j == pattern.length())
            {
                cout << i << '\n';
                i += j;
            }
            else
                i++;
        }
    }
    else
        return 0;

    for (auto &i : result(printer, pattern))
        cout << i << ' ';

    return 0;
}
