//przybli�ona warto�� pierwiastka kwadratowego liczby rzeczywistej wi�kszej od 1

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n;
    cin >> n;

    cout << sqrt(n) << '\n';

    return 0;
}
