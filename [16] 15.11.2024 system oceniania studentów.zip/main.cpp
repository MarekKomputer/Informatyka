#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

struct info
{
    unsigned short nr;
    string name;
    vector<int> grade;

    bool renault;
};

int main()
{
    vector<vector<int>> kolk;

    cout << "jd" << '\n';

    return 0;
}
