#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main()
{
    ifstream plik("slowa-txt.txt");

    vector<string> wd;
    string i;

    while (!plik.eof())
    {
        plik >> i;
        wd.push_back(i);
    }

    for (auto& wd_one : wd)
        cout << wd_one << '\n';


    return 0;
}
