#include <iostream>
using namespace std;

class car
{
    public:
        string name;
        float price;
        void menu();
        int NWW(int a,int b);
    private:
        int mainownik;
        int NWD(int a,int b);
};

int car::NWD(int a, int b)
{
    while (a != b)
    {
        if (a > b)
            a -= b;
        else
            b -= a;
    }

    return a;
}

int car::NWW(int a, int b)
{
    while (b != 0)
    {
        int woner = b;
        b = a % b;
        a = woner;
    }

    // return a * b / NWD(a, b)
    return a;
}

int main()
{
    int a, b;
    cin >> a >> b;
    car autobus;
    cout << autobus.NWW(a, b) << '\n';
    cout << (a * b) / autobus.NWW(a, b) << '\n';

    // aM = 8, bM = 12;
    // 96 / NWD (4) = 24

    return 0;
}
