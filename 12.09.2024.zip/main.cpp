#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
using namespace std;

vector<double> d_we_x;
vector<double> d_we_y;
// dane wej�ciowe

struct punkt
{
    double x, y;
};

vector<punkt> pkt;

int main()
{
    ifstream we("wuz2-zad-1-punktytxt.txt");

    punkt p[100];
    int i = 0;

    while (!we.eof())
    {
        we >> p[i].x >> p[i].y;
        d_we_x.push_back(p[i].x);
        d_we_y.push_back(p[i].x);
        i++;
    }

    we.close();

    cout << p[0].x << ' ' << p[0].y << '\n';

    return 0;
}
