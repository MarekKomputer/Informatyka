#include <iostream>
using namespace std;

long long Trapez(long long a, long long b, long long h)
{
    cin >> a >> b >> h;
    long long P = ((a + b) * h) / 2;
    cout << P;

    return P;
}

int main()
{
    int a, b, h;
    Trapez(a, b, h);

    return 0;
}
