#include <iostream>
using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int a, b;
    cin >> a >> b;

    if (a == 0)
        if (b == 0)
        {
            cout << "to�samo�ciowe" << '\n';
            return 0;
        }
        else
        {
            cout << "sprzeczne" << '\n';
            return 0;
        }

    double x;
    x = -b / a;

    cout << x << '\n';

    return 0;
}
